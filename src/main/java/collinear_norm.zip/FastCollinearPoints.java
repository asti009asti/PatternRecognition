import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;

public class FastCollinearPoints {

    private ArrayList<ArrayList<Point>> ls;

    public FastCollinearPoints(Point[] points) {
        // finds all line segments containing 4 or more points
        if (points == null) {
            throw new java.lang.NullPointerException();
        }
        Point[] pointsAux = new Point[points.length];
        Point[] pointsCopy = new Point[points.length];
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) {
                throw new java.lang.NullPointerException();
            }
            //pointsAux[i] = points[i];
        }

        System.arraycopy(points, 0, pointsAux, 0, points.length );
        System.arraycopy(points, 0, pointsCopy, 0, points.length );

        Arrays.sort(points);

        ls = new ArrayList<ArrayList<Point>>();

        for (int i = 0; i < points.length; i++) {
            // sort all points by each point slope in ascending order
            Arrays.sort(pointsAux, points[i].slopeOrder());

            if ((pointsAux.length > 1) && (points[i].slopeTo(pointsAux[1]) == Double.NEGATIVE_INFINITY)) {
                throw new IllegalArgumentException();
            }
            ArrayList<Point> segmentPoints = new ArrayList<Point>();
            int count = 0;
            Point start = points[i];
            Point end = points[i];
            for (int indexAux = pointsAux.length - 1; indexAux > 0; indexAux--) {
                if (points[i].slopeTo(pointsAux[indexAux]) == points[i].slopeTo(pointsAux[indexAux - 1])) {
                    if (pointsAux[indexAux].compareTo(start) < 0)
                        start = pointsAux[indexAux];
                    else if (pointsAux[indexAux].compareTo(end) > 0)
                        end = pointsAux[indexAux];
                    count = count + 1;
                }
                else if (count >= 2) {
                    if (pointsAux[indexAux].compareTo(start) < 0)
                        start = pointsAux[indexAux];
                    else if (pointsAux[indexAux].compareTo(end) > 0)
                        end = pointsAux[indexAux];
                    segmentPoints.add(start);
                    segmentPoints.add(end);

                    if (!exists(segmentPoints)) {
                        ls.add(segmentPoints);
                    }
                    break;
//                    segmentPoints = new ArrayList<Point>();
//                    count = 0;
//                    start = points[i];
//                    end = points[i];
                }
                else {
                    segmentPoints = new ArrayList<Point>();
                    count = 0;
                    start = points[i];
                    end = points[i];
                }

            }

        }

        System.arraycopy(pointsCopy, 0, points, 0, points.length );
    }

    private boolean exists(ArrayList<Point> currentSegment) {
        for (ArrayList<Point> aSegment : ls) {
            if ((aSegment.get(0).compareTo(currentSegment.get(0)) == 0) &&
                    (aSegment.get(aSegment.size()-1).compareTo(currentSegment.get(currentSegment.size()-1)) == 0)) {
                return true;
            }
        }
        return false;
    }


    public int numberOfSegments() {
        // the number of line segments
        return ls.size();
    }

    public LineSegment[] segments() {
        // the line segments
        LineSegment[] segments = new LineSegment[ls.size()];
        for (int i = 0; i < segments.length; i++) {
            segments[i] = new LineSegment(ls.get(i).get(0), ls.get(i).get(ls.get(i).size()-1));
        }
        return segments;
    }

    public static void main(String[] args) {

        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }

}
